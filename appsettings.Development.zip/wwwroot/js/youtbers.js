﻿document.addEventListener('DOMContentLoaded', function () {
    var players = videojs.getPlayers();
    for (var playerId in players) {
        if (players.hasOwnProperty(playerId)) {
            players[playerId].dispose();
        }
    }

    var videos = document.querySelectorAll('video.video-js');
    for (var i = 0; i < videos.length; i++) {
        videojs(videos[i], {
            controls: true,
            autoplay: false,
            preload: 'auto'
        });
    }
});
