﻿namespace myweb0._2.Models
{
    public class Genealogia
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public string? Apellido { get; set; }
        public string? Relacion { get; set; } 
        public DateTime? FechaNacimiento { get; set; }
        public string? Imagen { get; set; }
    }
}
