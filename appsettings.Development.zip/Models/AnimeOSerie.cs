﻿namespace myweb0._2.Models
{
    public class AnimeOSerie
    {
        public int Id { get; set; }
        public string? Titulo { get; set; }
        public string? Tipo { get; set; } 
        public string? Enlace { get; set; } 
    }
}
